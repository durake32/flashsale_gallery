<div class="card-icon">
    <i class="far fa-file-alt fa-2x"></i>
</div>