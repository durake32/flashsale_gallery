<div class="card">
    <div class="card-body">
        <div class="box-header with-border">
            <h3 class="box-title">Delivery Date</h3>
        </div>
        <div class="box-footer" style="display: block;">
            <input class="form-control" type="date" value="{{ $order->delivery_date }}" name="delivery_date">
        </div>
    </div>
</div>
