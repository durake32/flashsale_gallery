<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <h4 class="card-title">Featured</h4>
    </div>
    <div class="card-body">
        <div class="box-footer" style="display: block;">
            <select class="browser-default custom-select" name="is_featured">
                <option selected value="">Select featured status</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
    </div>
</div>