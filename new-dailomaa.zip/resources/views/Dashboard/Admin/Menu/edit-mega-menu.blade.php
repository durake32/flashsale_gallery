<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">arrow_drop_down</i>
        </div>
        <h4 class="card-title">Mega Menu</h4>
    </div>
    <div class="card-body">
        <div class="box-footer" style="display: block;">
            <select class="browser-default custom-select" name="mega_menu">
                <option selected value="">Select Status</option>
                <option value="1" {{$menu->mega_menu == 1 ? 'selected' : ''}}>Yes</option>
                <option value="0" {{$menu->mega_menu == 0 ? 'selected' : ''}}>No</option>
            </select>
        </div>
    </div>
</div>