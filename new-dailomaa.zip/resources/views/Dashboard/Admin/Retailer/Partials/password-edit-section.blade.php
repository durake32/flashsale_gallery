<div class="card ">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">contacts</i>
        </div>
        <h4 class="card-title">Password</h4>
    </div>


    <div class="card-body">
        <div class="box-footer" style="display: block;">
           
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#changePasswordModal">
                Change Password
            </button>
        </div>
    </div>
    @include('Dashboard.Admin.Retailer.Partials.change-password-modal')

</div>
