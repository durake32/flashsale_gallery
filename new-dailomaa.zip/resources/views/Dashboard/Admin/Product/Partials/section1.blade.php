<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <h4 class="card-title">Nepali Product</h4>
    </div>
    <div class="card-body">
        <div class="box-footer" style="display: block;">
            <select class="browser-default custom-select" name="section1">
                <option selected value="">Select product type</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>
    </div>
</div>