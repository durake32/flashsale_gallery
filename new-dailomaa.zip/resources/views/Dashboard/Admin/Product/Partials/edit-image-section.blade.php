<div class="card ">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">contacts</i>
        </div>
        <h4 class="card-title">Image</h4>
    </div>
    <div class="card-body ">
        <div class="row">

            <div class="col-md-12 col-sm-4" style="margin-bottom:165px;">

                <div class="custom-file">
                     <label class="custom-file-label input-images-1 displayImage" for="images"></label>
                    <input type="file" name="image[]" class="custom-file-input" id="images" multiple="multiple">

              </div>
          </div>
            </div>
        </div>
    </div>

