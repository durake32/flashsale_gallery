<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DirectCategory extends Model
{
    protected $table="direct_categories";
    protected $guarded=[];
    public $timestamps = false;

}